-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 23, 2012 at 10:25 PM
-- Server version: 5.5.28
-- PHP Version: 5.3.10-1ubuntu3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `CRUD_Extjs4`
--

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

CREATE TABLE IF NOT EXISTS `Users` (
  `userID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `age` int(3) NOT NULL,
  PRIMARY KEY (`userID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`userID`, `name`, `lastname`, `age`) VALUES
(1, 'Ernesto', 'Ramirez', 23),
(2, 'Maria', 'Hurtado', 23),
(3, 'Jonathan', 'Caballero', 28),
(4, 'Susana', 'Villal', 25),
(5, 'Eduardo', 'edd', 21),
(6, 'Blanca', 'Rodriguez', 27),
(7, 'Javier', 'Ramirez', 32),
(8, 'Extjs', 'Sencha', 7),
(9, 'Touch', 'Sencha', 2),
(10, 'Architect', 'Sencha', 1),
(13, 'fdsfa', 'dsafdaf', 3543),
(14, 'dfwre', 'werw', 4354),
(15, 'Nitza', '', 0),
(16, 'Nitza', 'Alfinas', 22);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
